<aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 "
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="<?php echo e(route('usuarios.admin')); ?>" target="_blank">

            <img src="<?php echo e(asset('web/images/logo.png')); ?>" class="navbar-brand-img h-100" alt="main_logo"
                style="margin-bottom: 30px;">
            <br>
            <span class="ms-1 font-weight-bold" style="margin-top: 30px;">
                <?php $perfil = App\Models\Perfil::find(auth()->user()->idPerfil);
                echo 'hola, ' . $perfil->nombres;
                ?>
            </span>
        </a>
    </div>
    <hr class="horizontal dark mt-0" style="margin-top: 60px!important;">
    <div class="collapse navbar-collapse  w-auto h-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <?php if($perfil->tipo == 'admin'): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('usuarios.admin')); ?>"
                        class="nav-link <?php echo e(request()->is('usuarios') ? 'active' : ''); ?>">
                        <div
                            class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                            <i class="ni ni-shop text-primary text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Usuarios</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('empresas.admin')); ?>"
                        class="nav-link <?php echo e(request()->is('empresas') ? 'active' : ''); ?>">
                        <div
                            class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                            <i class="ni ni-shop text-primary text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Empresas</span>
                    </a>
                </li>
             
                <li class="nav-item">
                    <a href="#" class="nav-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                        <div
                            class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                            <i class="ni ni-shop text-primary text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Roles Empresas</span>
                    </a>
                </li>
            <?php else: ?>
                <?php if($perfil->tipo == 'empresa'): ?>
                    <li class="nav-item">
                        <a data-bs-toggle="collapse" href="#web"
                            class="nav-link <?php echo e(request()->is('datos-empresa') || request()->is('redes-sociales') || request()->is('sliders') ? 'active' : ''); ?>"
                            aria-controls="web" role="button" aria-expanded="false">
                            <div
                                class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                                <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Web</span>
                        </a>
                        <div class="collapse " id="web">
                            <ul class="nav ms-4">
                                <li class="nav-item ">
                                    <a class="nav-link  <?php echo e(request()->is('datos-empresa') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('datos.empresa')); ?>">
                                        <span class="sidenav-mini-icon"> DE </span>
                                        <span class="sidenav-normal"> Datos de la Empresa <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('redes-sociales') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('redes.empresa')); ?>">
                                        <span class="sidenav-mini-icon"> RS </span>
                                        <span class="sidenav-normal"> Redes Sociales <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('sliders') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('sliders.index')); ?>">
                                        <span class="sidenav-mini-icon"> S </span>
                                        <span class="sidenav-normal"> Sliders <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('publicaciones') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('publicaciones.index')); ?>">
                                        <span class="sidenav-mini-icon"> S </span>
                                        <span class="sidenav-normal"> Publicaciones <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('botones') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('botones.index')); ?>">
                                        <span class="sidenav-mini-icon"> S </span>
                                        <span class="sidenav-normal"> Botones <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('servicios') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('servicios.index')); ?>">
                                        <span class="sidenav-mini-icon"> S </span>
                                        <span class="sidenav-normal"> Servicios <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('testimonios') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('testimonios.index')); ?>">
                                        <span class="sidenav-mini-icon"> S </span>
                                        <span class="sidenav-normal"> Testimonios <b class="caret"></b></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a data-bs-toggle="collapse" href="#elecciones"
                            class="nav-link <?php echo e(request()->is('departamentos') || request()->is('provincias') || request()->is('distritos') || request()->is('zonas') ? 'active' : ''); ?>"
                            aria-controls="elecciones" role="button" aria-expanded="false">
                            <div
                                class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                                <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Ubigeo</span>
                        </a>
                        <div class="collapse " id="elecciones">
                            <ul class="nav ms-4">
                                <li class="nav-item ">
                                    <a class="nav-link  <?php echo e(request()->is('departamentos') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('departamentos.index')); ?>">
                                        <span class="sidenav-mini-icon"> D </span>
                                        <span class="sidenav-normal"> Departamentos <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('provincias') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('provincias.index')); ?>">
                                        <span class="sidenav-mini-icon"> P </span>
                                        <span class="sidenav-normal"> Provincias <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('distritos') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('distritos.index')); ?>">
                                        <span class="sidenav-mini-icon"> D </span>
                                        <span class="sidenav-normal"> Distritos <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('zonas') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('zonas.index')); ?>">
                                        <span class="sidenav-mini-icon"> Z </span>
                                        <span class="sidenav-normal"> Zonas <b class="caret"></b></span>
                                    </a>
                                </li>
                                
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a data-bs-toggle="collapse" href="#partidos"
                            class="nav-link <?php echo e(request()->is('partidos') || request()->is('provincias') ? 'active' : ''); ?>"
                            aria-controls="partidos" role="button" aria-expanded="false">
                            <div
                                class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                                <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Partidos y Candidatos</span>
                        </a>
                        <div class="collapse " id="partidos">
                            <ul class="nav ms-4">
                                <li class="nav-item ">
                                    <a class="nav-link  <?php echo e(request()->is('partidos') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('partidos.index')); ?>">
                                        <span class="sidenav-mini-icon"> P </span>
                                        <span class="sidenav-normal"> Partidos <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->is('provincias') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('candidatos.index')); ?>">
                                        <span class="sidenav-mini-icon"> c </span>
                                        <span class="sidenav-normal"> Candidatos <b class="caret"></b></span>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a ref="#" class="nav-link ">
                            <div
                                class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                                <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Crear Encuestas</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a ref="#" class="nav-link ">
                            <div
                                class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                                <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Votos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a data-bs-toggle="collapse" href="#resultados" class="nav-link " aria-controls="resultados"
                            role="button" aria-expanded="false">
                            <div
                                class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                                <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Resultados y Gráficos</span>
                        </a>
                        <div class="collapse " id="resultados">
                            <ul class="nav ms-4">
                                <li class="nav-item ">
                                    <a class="nav-link  " href="#">
                                        <span class="sidenav-mini-icon"> R </span>
                                        <span class="sidenav-normal"> Resultados <b class="caret"></b></span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link " href="#">
                                        <span class="sidenav-mini-icon"> G </span>
                                        <span class="sidenav-normal"> Gráficos <b class="caret"></b></span>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </li>
                    
                <?php else: ?>
                <?php endif; ?>
            <?php endif; ?>
            <li class="nav-item">
                <a data-bs-toggle="collapse" href="#web"
                    class="nav-link <?php echo e(request()->is('datos-empresa') || request()->is('redes-sociales') || request()->is('sliders') ? 'active' : ''); ?>"
                    aria-controls="web" role="button" aria-expanded="false">
                    <div
                        class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-ungroup text-warning text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Configuracion</span>
                </a>
                <div class="collapse " id="web">
                    <ul class="nav ms-4">
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/area') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.area')); ?>">
                                <span class="sidenav-normal"> Area <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/cargo') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.cargo')); ?>">
                                <span class="sidenav-normal"> Cargo <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/estadoActividad') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.estadoActividad')); ?>">
                                <span class="sidenav-normal"> Estado Actividad <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/estadoEvaluacion') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.estadoEvaluacion')); ?>">
                                <span class="sidenav-normal"> Estado Evaluacion <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/estadoGestion') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.estadoGestion')); ?>">
                                <span class="sidenav-normal"> Estado Gestion <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/estadoProceso') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.estadoProceso')); ?>">
                                <span class="sidenav-normal"> Estado Proceso <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/funcion') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.funcion')); ?>">
                                <span class="sidenav-normal"> Funcion <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/personal') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.personal')); ?>">
                                <span class="sidenav-normal"> Personal <b class="caret"></b></span>
                            </a>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/prioridad') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.prioridad')); ?>">
                                <span class="sidenav-normal"> Prioridad <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/tipoActividad') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.tipoActividad')); ?>">
                                <span class="sidenav-normal"> Tipo Actividad <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/tipoUbigeo') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.tipoUbigeo')); ?>">
                                <span class="sidenav-normal"> Tipo Ubigeo <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/tipoUsuario') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.tipoUsuario')); ?>">
                                <span class="sidenav-normal"> Tipo Usuario <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/usuarioResponsable') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.usuarioResponsable')); ?>">
                                <span class="sidenav-normal"> Usuario Responsable <b class="caret"></b></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link  <?php echo e(request()->is('configuracion/vinculo') ? 'active' : ''); ?>"
                                href="<?php echo e(route('configuracion.vinculo')); ?>">
                                <span class="sidenav-normal"> Vinculo <b class="caret"></b></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
</aside>
<?php /**PATH C:\Users\angel\Documents\sige-cambios\resources\views/intranet/layouts/menu.blade.php ENDPATH**/ ?>